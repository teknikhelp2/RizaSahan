using System;using System.Data;using System.Data.OleDb;using System.Collections.Generic;
class DbTool {
 static OleDbConnection Open(string p){var b=new OleDbConnectionStringBuilder();b.Provider="Microsoft.Jet.OLEDB.4.0";b.DataSource=System.IO.Path.GetFullPath(p);b["Mode"]="ReadWrite";var c=new OleDbConnection(b.ConnectionString);c.Open();return c;}
 static bool Has(OleDbConnection c,string t){using(var s=c.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,new object[]{null,null,t,"TABLE"}))return s.Rows.Count==1;}
 static int Main(string[] a){try{
  if(a.Length!=2 || (a[0]!="validate"&&a[0]!="resume"))throw new Exception("DbTool validate|resume <Ticket.mdb>");
  using(var c=Open(a[1])){
   foreach(var t in new[]{"TicketMeta","Users","Settings","Tickets","Attachments","Categories","LoginSessions","ResetTokens","LoginAttempts"})if(!Has(c,t))throw new Exception("Ticket MDB tablosu eksik: "+t);
   using(var cmd=new OleDbCommand("SELECT COUNT(*) FROM Users WHERE IsActive=True AND RoleName='admin'",c))if(Convert.ToInt32(cmd.ExecuteScalar())<1)throw new Exception("Yedekte aktif yonetici yok. Farkli Ticket yedegi kullanin.");
   using(var cmd=new OleDbCommand("SELECT TOP 1 ID,PasswordHash FROM Users",c))using(var r=cmd.ExecuteReader()){if(!r.Read()||r.IsDBNull(1))throw new Exception("Kullanici parolalari okunamadi.");}
   if(a[0]=="resume")using(var tx=c.BeginTransaction()){foreach(var t in new[]{"LoginSessions","ResetTokens","LoginAttempts"})using(var cmd=new OleDbCommand("DELETE FROM ["+t+"]",c,tx))cmd.ExecuteNonQuery();tx.Commit();}
  }Console.WriteLine(a[0]=="resume"?"PASS: Eski oturumlar temizlendi; kullanicilar, parolalar, ticketler ve ayarlar korundu.":"PASS: Ticket MDB ve temel tablolar okunuyor; aktif yonetici var.");return 0;
 }catch(Exception e){Console.Error.WriteLine(e.Message);return 1;}}
}
