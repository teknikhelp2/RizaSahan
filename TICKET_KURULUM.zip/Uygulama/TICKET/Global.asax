<%@ Application Language="C#" %>
<script runat="server">
void Application_BeginRequest(object sender, System.EventArgs e){if(CelikelTicket.Deployment.Begin(Context))return;if(!CelikelTicket.BackupHeartbeat.Local(Context))CelikelTicket.SecurityPolicy.Begin(Context);}
void Application_Start(object sender, System.EventArgs e){try{CelikelTicket.Store.Init(Server.MapPath("~/"));CelikelTicket.ScheduledJobs.Start();CelikelTicket.Mailer.Kick();}catch{}}
</script>
