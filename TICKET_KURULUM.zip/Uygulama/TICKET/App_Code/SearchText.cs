using System;using System.Text;
namespace CelikelTicket {
public static class SearchText {
 // ANSI-92 LIKE character classes avoid Jet's unavailable VBA Replace function.
 public static string Pattern(string value){var b=new StringBuilder("%");foreach(char c in value??""){if(c=='i'||c=='I'||c=='İ'||c=='ı')b.Append("[iIİı]");else if(c=='[')b.Append("[[]");else if(c=='%')b.Append("[%]");else if(c=='_')b.Append("[_]");else b.Append(c);}return b.Append('%').ToString();}
 public static string PhonePattern(string value){var b=new StringBuilder("%");foreach(char c in value??""){b.Append(c);b.Append('%');}return b.ToString();}
 public static string Fold(string value){return (value??"").Replace('İ','i').Replace('I','i').Replace('ı','i').ToLowerInvariant();}
 public static bool Contains(string value,string query){return Fold(value).IndexOf(Fold(query),StringComparison.Ordinal)>=0;}
}
}
