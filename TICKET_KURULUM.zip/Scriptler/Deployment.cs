using System;using System.IO;using System.Web;
namespace CelikelTicket {
 public static class Deployment {
  public static bool AutomationAllowed { get {return !File.Exists(Path.Combine(HttpRuntime.AppDomainAppPath,"App_Data","OTOMASYON-DURAKLATILDI.txt"));} }
  public static bool Begin(HttpContext c){
   string prefix=VirtualPathUtility.ToAbsolute("~/"),path=c.Request.Url.AbsolutePath;
   if(path.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)&&!path.StartsWith(prefix,StringComparison.Ordinal)){
    c.Response.StatusCode=307;c.Response.RedirectLocation=prefix+path.Substring(prefix.Length)+c.Request.Url.Query;c.Response.Cache.SetNoStore();c.ApplicationInstance.CompleteRequest();return true;
   }
   if(!AutomationAllowed && c.Request.FilePath.EndsWith("/app/backup-heartbeat.ashx",StringComparison.OrdinalIgnoreCase)){
    c.Response.ContentType="application/json";c.Response.Write("{\"ok\":true,\"paused\":true}");c.ApplicationInstance.CompleteRequest();return true;
   }return false;
  }
 }
}