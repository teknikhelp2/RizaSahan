﻿param([string]$Source='', [switch]$Restore)
Import-Module WebAdministration
$exists=Sahiplik-Kontrol
if($exists -and -not$Restore){
 Havuzu-Durdur
 try{Maintenance-Korumasi-Kur $Target}finally{Start-WebAppPool $Pool}
 Gizli-Dosyalari-Kontrol
 Plan-Gorevi-Kur;Mesaj 'TICKET zaten kurulu. Web dosya korumasi yenilendi; veriler ve parolalar korundu, bos veritabani yazilmadi.' OK;return
}
if(-not$Source){$Source=Join-Path $Kit 'Uygulama\TICKET'}
$stage=Join-Path $Kit ('Gecici\kur-'+[guid]::NewGuid().ToString('N'));Agac-Kopyala $Source $stage
Kurtarma-Uyarla $stage ([bool]$Restore)
Calistir "$Kit\Scriptler\DbTool.exe" @('validate',"$stage\App_Data\Ticket.mdb")
if($Restore){Calistir "$Kit\Scriptler\DbTool.exe" @('resume',"$stage\App_Data\Ticket.mdb")}
$compile=Join-Path $Kit ('Gecici\compile-'+[guid]::NewGuid().ToString('N'))
Calistir "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\aspnet_compiler.exe" @('-v','/TICKET','-p',$stage,$compile)
$rollback='';$committed=$false;$newPool=$false;$newApp=$false;$wasStarted=$false
if(Test-Path "IIS:\AppPools\$Pool"){$wasStarted=(Get-WebAppPoolState $Pool).Value -eq 'Started';Havuzu-Durdur}
try{
 if(Test-Path -LiteralPath $Target){
  $saved='C:\TICKET_YEDEKLERI';$null=Yerel $saved;New-Item -ItemType Directory -Path $saved -Force | Out-Null
  $rollback=Join-Path $saved ('Degisim-Oncesi-'+(Get-Date -Format yyyyMMdd-HHmmss)+'-'+[guid]::NewGuid().ToString('N').Substring(0,6))
  Move-Item -LiteralPath $Target -Destination $rollback
 }
 New-Item -ItemType Directory -Path (Split-Path $Target -Parent) -Force | Out-Null
 Move-Item -LiteralPath $stage -Destination $Target
 if(-not(Test-Path "IIS:\AppPools\$Pool")){New-WebAppPool -Name $Pool | Out-Null;$newPool=$true}
 Set-ItemProperty "IIS:\AppPools\$Pool" managedRuntimeVersion 'v4.0'
 Set-ItemProperty "IIS:\AppPools\$Pool" managedPipelineMode 'Integrated'
 Set-ItemProperty "IIS:\AppPools\$Pool" enable32BitAppOnWin64 $true
 Set-ItemProperty "IIS:\AppPools\$Pool" processModel.identityType 4
 Set-ItemProperty "IIS:\AppPools\$Pool" processModel.loadUserProfile $true
 Set-ItemProperty "IIS:\AppPools\$Pool" processModel.maxProcesses 1
 Set-ItemProperty "IIS:\AppPools\$Pool" processModel.idleTimeout ([TimeSpan]::Zero)
 if($exists){Remove-WebApplication -Site $Site -Name TICKET}
 New-WebApplication -Site $Site -Name TICKET -PhysicalPath $Target -ApplicationPool $Pool | Out-Null;$newApp=$true
 Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Location "$Site/TICKET" -Filter 'system.webServer/security/authentication/anonymousAuthentication' -Name enabled -Value $true
 Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Location "$Site/TICKET" -Filter 'system.webServer/security/authentication/anonymousAuthentication' -Name userName -Value ''
 Calistir "$env:WINDIR\System32\icacls.exe" @($Target,'/grant',"IIS AppPool\${Pool}:(OI)(CI)(RX)",'/T','/Q')
 Calistir "$env:WINDIR\System32\icacls.exe" @("$Target\App_Data",'/grant',"IIS AppPool\${Pool}:(OI)(CI)(M)",'/T','/Q')
 [ordered]@{Kind='TICKET-KURULUM';Computer=$env:COMPUTERNAME;Target=$Target;Pool=$Pool;Version='2026.11.17';Restored=[bool]$Restore} | ConvertTo-Json | Set-Content "$Target\App_Data\kurulum.json" -Encoding UTF8
 Start-WebAppPool $Pool
 if((Get-Website -Name $Site).State -ne 'Started'){Start-Website $Site}
 $response=Invoke-WebRequest 'http://localhost/TICKET/index.aspx' -UseBasicParsing -TimeoutSec 90
 if($response.StatusCode -ne 200 -or $response.Content -notmatch 'login-form'){throw 'Giris ekrani dogrulanamadi.'}
 Gizli-Dosyalari-Kontrol
 $committed=$true
}catch{
 $failure=$_;try{if(Test-Path "IIS:\AppPools\$Pool"){Havuzu-Durdur};if($newApp){Remove-WebApplication -Site $Site -Name TICKET};if(Test-Path -LiteralPath $Target){$failed=Join-Path $Kit ('Gecici\basarisiz-'+[guid]::NewGuid().ToString('N'));Move-Item -LiteralPath $Target -Destination $failed};if($rollback){Move-Item -LiteralPath $rollback -Destination $Target;New-WebApplication -Site $Site -Name TICKET -PhysicalPath $Target -ApplicationPool $Pool | Out-Null;if($wasStarted){Start-WebAppPool $Pool}}elseif($newPool){Remove-WebAppPool $Pool}}catch{Mesaj "Geri alma tamamlanamadi: $($_.Exception.Message). Korunan klasor: $rollback" Hata};throw $failure
}
if($committed){
 # Separate task; never edits any ITCONTROL task, pool or file.
 Plan-Gorevi-Kur
 Mesaj 'BASARILI: http://localhost/TICKET/' OK
 Mesaj "Diger bilgisayarlar: http://$env:COMPUTERNAME/TICKET/"
 if($Restore){Mesaj 'Yedekteki kullanici adi ve parolanizla giris yapin. Verileriniz geri yuklendi.' OK;Mesaj 'Mail ve otomasyon duraklatildi. Adres/mail ayarlarini kontrol edin; sonra 3-OTOMASYONU-AC.bat calistirin. Ayrinti: BASLA.html.' Uyari;Mesaj 'Port 80 icin eski HTTPS zorunlulugu yerel kurtarma dosyasiyla gecici askiya alindi. Parola ilkeleri korunur.' Uyari}else{Mesaj 'BOS KURULUM: admin / admin. Ilk giriste parolayi degistirin; sirketinizi ve logonuzu tanimlayin.' OK}
 if($rollback){Mesaj "Onceki kurulum silinmedi: $rollback"}
}
