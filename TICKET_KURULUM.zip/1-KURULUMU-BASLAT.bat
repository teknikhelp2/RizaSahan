@echo off
setlocal
echo TICKET
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Scriptler\Baslat.ps1" -Islem Kur
set "sonuc=%errorlevel%"
pause
exit /b %sonuc%
