using System;using System.Linq;
namespace CelikelTicket {
public static class TicketPeople {
 public static object Requester(Api a){var ticket=a.Ticket(a.N("ticket"));var person=Store.One(a.Db,"SELECT u.ID,u.FirstName,u.LastName,u.Email,u.Department,u.JobTitle,u.Phone,u.PhotoFile,m.FirstName AS ManagerFirst,m.LastName AS ManagerLast,l.Title AS LocationTitle FROM (TicketPeopleHistory u LEFT JOIN TicketPeopleHistory m ON u.ManagerID=m.ID) LEFT JOIN Locations l ON u.LocationID=l.ID WHERE u.ID=?",Store.Int(ticket["RequesterID"]));if(person==null)throw new Fault("Talep sahibi bilgileri bulunamadı.",404);return new{id=Store.Int(person["ID"]),displayName=(Store.Text(person["FirstName"])+" "+Store.Text(person["LastName"])).Trim(),department=Store.Text(person["Department"]),jobTitle=Store.Text(person["JobTitle"]),email=Store.Text(person["Email"]),phone=Store.Text(person["Phone"]),location=Store.Text(person["LocationTitle"]),manager=(Store.Text(person["ManagerFirst"])+" "+Store.Text(person["ManagerLast"])).Trim(),photo=Store.Text(person["PhotoFile"])};}
}
}
