Option Explicit
Const WORKER_URL = "http://localhost/ticket/app/backup-heartbeat.ashx"
Dim req,fso,shell,logDir,logFile,code,message,n
Set fso=CreateObject("Scripting.FileSystemObject"):Set shell=CreateObject("WScript.Shell")
logDir=shell.ExpandEnvironmentStrings("%ProgramData%") & "\Celikel"
On Error Resume Next
If Not fso.FolderExists(logDir) Then fso.CreateFolder logDir
Set req=CreateObject("WinHttp.WinHttpRequest.5.1")
req.SetProxy 1
req.SetTimeouts 5000,10000,10000,120000
req.Open "POST",WORKER_URL,False
req.SetRequestHeader "Content-Type","application/x-www-form-urlencoded"
req.Send ""
n=Err.Number:message=Err.Description:Err.Clear:code=1
If n=0 Then
 If req.Status=200 Then
  If InStr(req.ResponseText,"""ok"":true")>0 Then code=0:message="Plan kontrol edildi. Son yedek sonucunu portal ekranindan kontrol edin."
 End If
 If code<>0 Then message="HTTP " & req.Status & ": IIS, uygulama yolu ve portal Son hata alanini kontrol edin."
End If
Set logFile=fso.CreateTextFile(logDir & "\Ticket-Backup-Worker.log",True,True)
logFile.WriteLine Now() & " | " & code & " | " & message:logFile.Close
On Error GoTo 0
WScript.Quit code
