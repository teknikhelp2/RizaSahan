using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

// .NET Framework 4.5+, x86 for Jet 4.0. No registration or PowerShell.
internal static class TicketBackupWorker {
    sealed class Item { public string Source, Name, Hash; public long Size; }
    static readonly StringComparer CI = StringComparer.OrdinalIgnoreCase;
    static readonly Regex Artifact = new Regex(@"^Ticket-(Auto-)?(Tam|MDB)-[0-9]{8}-[0-9]{6}-[a-f0-9]{6}\.zip(\.partial)?$", RegexOptions.IgnoreCase);
    static readonly Regex FinalName = new Regex(@"^Ticket-(Auto-)?(Tam|MDB)-[0-9]{8}-[0-9]{6}-[a-f0-9]{6}\.zip$");
    static readonly List<Item> Items = new List<Item>();
    static readonly HashSet<string> Names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    static readonly List<string> Excludes = new List<string>();
    static string database, snapshot, job, destination, partial;
    static long total, bytes, files;
    static bool databaseAdded;
    static DateTime lastEvent = DateTime.MinValue;
    static string Full(string p) { return Path.GetFullPath(p).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar); }
    static bool Inside(string p, string parent) { p=Full(p);parent=Full(parent);return CI.Equals(p,parent)||p.StartsWith(parent+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase); }
    static void Event(string phase, string message, bool force) {
        if(!force && (DateTime.UtcNow-lastEvent).TotalSeconds<1) return;
        lastEvent=DateTime.UtcNow;
        WriteStatus(phase,message);
        Console.WriteLine(phase+"|"+bytes+"|"+total+"|"+files+"|"+Convert.ToBase64String(Encoding.UTF8.GetBytes(message)));
        Console.Out.Flush();
    }
    static void WriteStatus(string phase,string message) {
        if(job==null || !Directory.Exists(job)) return;
        try {
            string target=Path.Combine(job,"status.xml"),temp=target+".tmp";
            using(var w=XmlWriter.Create(temp,new XmlWriterSettings{Encoding=new UTF8Encoding(false),Indent=false})) {
                w.WriteStartElement("status");w.WriteAttributeString("phase",phase);w.WriteAttributeString("message",message);
                w.WriteAttributeString("bytes",bytes.ToString(System.Globalization.CultureInfo.InvariantCulture));
                w.WriteAttributeString("total",total.ToString(System.Globalization.CultureInfo.InvariantCulture));
                w.WriteAttributeString("files",files.ToString(System.Globalization.CultureInfo.InvariantCulture));
                w.WriteAttributeString("utc",DateTime.UtcNow.ToString("o"));w.WriteEndElement();
            }
            if(File.Exists(target)) File.Replace(temp,target,null);else File.Move(temp,target);
        } catch { /* The supervisor also consumes stdout; the next event retries durable status. */ }
    }
    static void NotLink(string p) {
        for(string a=Full(p); !String.IsNullOrEmpty(a); a=Path.GetDirectoryName(a))
            if((File.GetAttributes(a)&FileAttributes.ReparsePoint)!=0) throw new IOException("Bağlantı/junction yolu kullanılamaz: "+a);
    }
    static bool Excluded(string path) {
        foreach(string e in Excludes) if(Inside(path,e)) return true;
        string n=Path.GetFileName(path);
        return CI.Equals(n,"backup")||CI.Equals(n,"backups")||CI.Equals(n,"yedek")||CI.Equals(n,"yedekler");
    }
    static void Add(string path,string name) {
        name=name.Replace('\\','/');
        if(!Names.Add(name)) throw new IOException("Yinelenen arşiv yolu: "+name);
        bool active=CI.Equals(Full(path),database);
        string source=active?snapshot:path;
        if(active) databaseAdded=true;
        NotLink(source);
        var info=new FileInfo(source);
        if(!info.Exists) throw new FileNotFoundException("Dosya bulunamadı",source);
        Items.Add(new Item{Source=source,Name=name,Size=info.Length}); total=checked(total+info.Length);
    }
    static void Scan(string folder,string name,int depth) {
        if(depth>100) throw new IOException("Klasör ağacı çok derin: "+folder);
        NotLink(folder);
        bool any=false;
        foreach(string p in Directory.EnumerateFiles(folder)) {
            string ext=Path.GetExtension(p),n=Path.GetFileName(p);
            if(CI.Equals(ext,".ldb")||CI.Equals(ext,".laccdb")||CI.Equals(ext,".partial")||CI.Equals(n,"maintenance.txt")||Artifact.IsMatch(n)) continue;
            Add(p,name+"/"+n);any=true;
            Event("scan","Yedek kapsamı taranıyor.",false);
        }
        foreach(string child in Directory.EnumerateDirectories(folder)) {
            if(Excluded(child)) continue;
            Scan(child,name+"/"+Path.GetFileName(child),depth+1);any=true;
        }
        if(!any) { string entry=name+"/";if(Names.Add(entry)) Items.Add(new Item{Name=entry}); }
    }
    static string HashFile(string p) {
        using(var h=SHA256.Create()) using(var f=new FileStream(p,FileMode.Open,FileAccess.Read,FileShare.Read,131072))
            return Convert.ToBase64String(h.ComputeHash(f));
    }
    static void Snapshot(string provider) {
        Event("snapshot","Veritabanının tutarlı kopyası alınıyor; kısa bakım sürüyor.",true);
        NotLink(database);
        // No application writes can start while the ASP maintenance lease is held.
        // Existing writers must drain; exclusive probe checks this before copying.
        using(var probe=new OleDbConnection("Provider="+provider+";Data Source="+database+";OLE DB Services=-2;Mode=Share Exclusive;")) { probe.Open(); }
        using(var gate=new OleDbConnection("Provider="+provider+";Data Source="+database+";OLE DB Services=-2;Mode=Share Deny Write;")) {
            gate.Open(); File.Copy(database,snapshot,false);
            if(new FileInfo(database).Length!=new FileInfo(snapshot).Length || HashFile(database)!=HashFile(snapshot))
                throw new IOException("MDB kopyasının bütünlüğü doğrulanamadı.");
        }
        // ASP receives this before reading another line, releases the lease and reopens DB.
        Event("snapshot-ready","MDB kopyası hazır. Portal kullanımı devam edebilir.",true);
    }
    static void CreateArchive(string info) {
        long verified=0;var buffer=new byte[131072];
        if(!destination.StartsWith(@"\\")) {
            var drive=new DriveInfo(Path.GetPathRoot(destination));
            if(drive.AvailableFreeSpace < total + total/100 + Items.Count*512L + 16777216L)
                throw new IOException("Yedek diskte yeterli boş alan yok. En az "+((total+total/100+Items.Count*512L+16777216L)/1048576)+" MB boş alan ayırın.");
        }
        Event("copy","Dosyalar ayrı işlemde diske paketleniyor.",true);
        using(var output=new FileStream(partial,FileMode.CreateNew,FileAccess.Write,FileShare.None,131072))
        using(var zip=new ZipArchive(output,ZipArchiveMode.Create,false,Encoding.UTF8)) {
            foreach(var item in Items) {
                var entry=zip.CreateEntry(item.Name,CompressionLevel.Fastest);
                if(item.Source==null) continue;
                DateTime modified=File.GetLastWriteTime(item.Source);
                if(modified.Year>=1980 && modified.Year<=2107) entry.LastWriteTime=modified;
                NotLink(item.Source);
                using(var input=new FileStream(item.Source,FileMode.Open,FileAccess.Read,FileShare.Read,131072))
                using(var target=entry.Open()) using(var hash=SHA256.Create()) {
                    if(input.Length!=item.Size) throw new IOException("Tarama sonrası dosya boyutu değişti: "+item.Name);
                    int n;long copied=0;
                    while((n=input.Read(buffer,0,buffer.Length))>0) {
                        target.Write(buffer,0,n);hash.TransformBlock(buffer,0,n,null,0);copied+=n;bytes+=n;
                        Event("copy","Dosyalar ayrı işlemde diske paketleniyor.",false);
                    }
                    hash.TransformFinalBlock(new byte[0],0,0);item.Hash=Convert.ToBase64String(hash.Hash);
                    if(copied!=item.Size) throw new IOException("Dosya boyutu değişti: "+item.Name);
                }
                files++;Event("copy","Dosyalar ayrı işlemde diske paketleniyor.",false);
            }
            var manifest=zip.CreateEntry("Yedek-Bilgisi.txt");
            using(var w=new StreamWriter(manifest.Open(),new UTF8Encoding(true))) {
                w.WriteLine(info);w.WriteLine("\r\nSHA-256 | Bayt | Arşiv yolu");
                foreach(var item in Items) if(item.Source!=null) w.WriteLine(item.Hash+" | "+item.Size+" | "+item.Name);
            }
        }
        // Read every entry back, not just the central directory or final file size.
        Event("verify","ZIP içindeki tüm dosyalar SHA-256 ile doğrulanıyor.",true);
        using(var input=new FileStream(partial,FileMode.Open,FileAccess.Read,FileShare.Read,131072))
        using(var zip=new ZipArchive(input,ZipArchiveMode.Read,false,Encoding.UTF8)) {
            if(zip.Entries.Count!=Items.Count+1) throw new IOException("ZIP kayıt sayısı uyuşmuyor.");
            foreach(var item in Items) {
                var entry=zip.GetEntry(item.Name);
                if(entry==null) throw new IOException("ZIP kaydı eksik: "+item.Name);
                if(item.Source==null) continue;
                using(var s=entry.Open()) using(var hash=SHA256.Create()) {
                    long length=0;int n;
                    while((n=s.Read(buffer,0,buffer.Length))>0) {hash.TransformBlock(buffer,0,n,null,0);length+=n;verified+=n;Event("verify","ZIP dosyaları doğrulanıyor: "+(verified/1048576)+" MB",false);}
                    hash.TransformFinalBlock(new byte[0],0,0);
                    if(length!=item.Size||Convert.ToBase64String(hash.Hash)!=item.Hash) throw new IOException("ZIP doğrulaması başarısız: "+item.Name);
                }
            }
        }
        File.Move(partial,destination); // Successful archives alone receive .zip.
        Event("complete","ZIP doğrulandı ve yayımlandı.",true);
    }
    static string Attr(XmlElement e,string key) {string v=e.GetAttribute(key);if(String.IsNullOrWhiteSpace(v)) throw new ArgumentException("Eksik ayar: "+key);return v;}
    static int Run(string manifest) {
        job=Full(Path.GetDirectoryName(manifest));
        var settings=new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null};
        var doc=new XmlDocument{XmlResolver=null};using(var r=XmlReader.Create(manifest,settings)) doc.Load(r);
        var c=doc.DocumentElement;
        database=Full(Attr(c,"database"));snapshot=Path.Combine(job,"database.mdb");
        destination=Full(Attr(c,"destination"));partial=destination+".partial";
        if(!FinalName.IsMatch(Path.GetFileName(destination))) throw new ArgumentException("Yedek dosya adı geçersiz.");
        string backup=Full(Attr(c,"backup")),root=Full(Attr(c,"root"));
        if(!CI.Equals(Path.GetDirectoryName(destination),backup)||Inside(root,backup)||Inside(database,backup)) throw new ArgumentException("Yedek/hedef konumları çakışıyor.");
        if(!Inside(job,Path.Combine(root,"App_Data","BackupJobs"))) throw new ArgumentException("İş klasörü geçersiz.");
        NotLink(job);NotLink(backup);
        Excludes.Add(backup);Excludes.Add(Path.Combine(root,"App_Data","Backups"));Excludes.Add(Path.GetDirectoryName(job));
        // File lock spans snapshot, scan, ZIP creation and verification, across IIS processes.
        using(var guard=new FileStream(Path.Combine(Path.GetDirectoryName(job),"worker.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)) {
            Snapshot(Attr(c,"provider"));
            Event("scan","Yedek kapsamı taranıyor.",true);
            bool full=c.GetAttribute("full")=="true";
            if(full) Scan(root,"ticket",0);
            var roots=new List<string>{root};
            foreach(XmlElement e in c.SelectNodes("extra")) {
                if(!full) continue;
                string folder=Full(Attr(e,"path")),name=Attr(e,"name");bool covered=false;
                if(!Regex.IsMatch(name,@"^(files|photos)$")) throw new ArgumentException("Harici klasör türü geçersiz.");
                foreach(string previous in roots) if(Inside(folder,previous)) covered=true;
                if(covered) continue;
                if(!Directory.Exists(folder)) throw new DirectoryNotFoundException("Tanımlı harici klasör bulunamadı: "+folder);
                if(Excluded(folder)) throw new IOException("Harici kaynak yedek klasörü ile çakışıyor: "+folder);
                Scan(folder,"external/"+name,0);roots.Add(folder);
            }
            if(!databaseAdded) Add(database,Attr(c,"databaseEntry"));
            CreateArchive(c.InnerText);
        }
        return 0;
    }
    public static int Main(string[] args) {
        try {
            if(args.Length==1&&args[0]=="--selftest") {
                using(var m=new MemoryStream()) using(var z=new ZipArchive(m,ZipArchiveMode.Create,true)) z.CreateEntry("runtime-check.txt");
                Console.WriteLine("Ticket BackupWorker V11.70 | .NET "+Environment.Version+" | Streaming ZIP / SHA-256 | OK");return 0;
            }
            if(args.Length!=1) throw new ArgumentException("İş tanımı gerekli.");
            // Keep ZIP CPU work at a lower priority than interactive portal requests.
            Process.GetCurrentProcess().PriorityClass=ProcessPriorityClass.BelowNormal;
            return Run(args[0]);
        } catch(Exception e) { Event("error",e.Message,true);return 1; }
        finally {
            // Never remove a completed archive. Only this job's transient files.
            if(partial!=null) {try{if(File.Exists(partial))File.Delete(partial);}catch{}}
            if(snapshot!=null) {try{if(File.Exists(snapshot))File.Delete(snapshot);}catch{}}
        }
    }
}
