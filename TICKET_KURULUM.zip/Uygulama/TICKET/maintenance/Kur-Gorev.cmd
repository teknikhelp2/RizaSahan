@echo off
cd /d "%~dp0"
"%SystemRoot%\System32\cscript.exe" //Nologo "Install-Backup-Task.vbs"
pause
