using System;using System.Linq;using System.Collections.Generic;using System.Text.RegularExpressions;using System.Web;
namespace CelikelTicket {
// Removes recognized signature regions, never guesses from an attachment's size/name alone.
public static class MailContent {
 static string Prefix(string html){
  html=html??"";int end=html.Length;
  var structural=Regex.Match(html,@"<(?:div|table|span|section)\b[^>]*(?:id|class)\s*=\s*['"" ][^>]*?(?:gmail_signature|moz-signature|\bSignature\b)[^>]*>",RegexOptions.IgnoreCase);
  if(structural.Success)end=structural.Index;
  var lines=Regex.Matches(html,@"(?:^|<br\s*/?>|</p>|</div>|\r?\n)\s*(?:<[^>]+>\s*)*(?:Saygılarımla|Saygilarimla|Saygılarımızla|Saygilarimizla|İyi çalışmalar|Iyi calismalar|Best regards|Kind regards|Regards|Sent from my iPhone|Outlook for (?:iOS|Android))\s*[.!,:;]*(?:\s|&nbsp;)*(?=<|\r?\n|$)",RegexOptions.IgnoreCase);
  foreach(Match line in lines)if(line.Index<end&&Files.Plain(html.Substring(0,line.Index)).Trim().Length>0){end=line.Index;break;}
  return html.Substring(0,end);
 }
 public static string WithoutSignature(string html){var prefix=Prefix(html);if(prefix==(html??""))return prefix;string clean=Files.CleanHtml(prefix);var stack=new List<string>();foreach(Match tag in Regex.Matches(clean,@"<(/?)([a-z0-9]+)\b[^>]*>",RegexOptions.IgnoreCase)){string name=tag.Groups[2].Value.ToLowerInvariant();if(name=="br"||name=="img")continue;if(tag.Groups[1].Value=="")stack.Add(name);else{int index=stack.LastIndexOf(name);if(index>=0)stack.RemoveRange(index,stack.Count-index);}}for(int i=stack.Count-1;i>=0;i--)clean+="</"+stack[i]+">";return clean;}
 public static HashSet<string> Cids(string html){return new HashSet<string>(Regex.Matches(html??"",@"cid:([^'""<>\s]+)",RegexOptions.IgnoreCase).Cast<Match>().Select(m=>HttpUtility.HtmlDecode(m.Groups[1].Value).Trim('<','>')),StringComparer.OrdinalIgnoreCase);}
 public static HashSet<string> SignatureCids(string html){var removed=Cids(html);removed.ExceptWith(Cids(Prefix(html)));return removed;}
 public static bool SignatureFile(string filename,HashSet<string> removed){return removed.Any(cid=>string.Equals(cid.Split('@')[0],filename,StringComparison.OrdinalIgnoreCase));}
}
}
