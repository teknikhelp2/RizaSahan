using System;
using System.IO;
using System.Linq;
using System.Data.OleDb;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;

namespace CelikelTicket {
public sealed class TicketBackupJob {
 public string id,name,destination,mode,error="",started,processStarted="";
 public int user,pid;public bool full,finished;
}
// Application requests hold Store.Gate only for the short MDB snapshot, never for ZIP CPU/I/O.
public static class TicketBackupJobs {
 static string Area {get {string p=Path.Combine(Store.Root,"App_Data","BackupJobs");Directory.CreateDirectory(p);return p;}}
 static string Active {get{return Path.Combine(Area,"active.txt");}}
 static string Folder(string id){if(!Regex.IsMatch(id??"",@"^[a-f0-9]{32}$"))throw new Fault("Yedek iş numarası geçersiz.");return Path.Combine(Area,id);}
 static void Atomic(string file,string value){string tmp=file+".tmp-"+Guid.NewGuid().ToString("N");File.WriteAllText(tmp,value,new UTF8Encoding(false));try{if(File.Exists(file))File.Replace(tmp,file,null);else File.Move(tmp,file);}finally{if(File.Exists(tmp))File.Delete(tmp);}}
 static void Save(TicketBackupJob j){Atomic(Path.Combine(Folder(j.id),"job.json"),Store.Json.Serialize(j));}
 static string ReadText(string file){using(var stream=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))using(var reader=new StreamReader(stream,Encoding.UTF8))return reader.ReadToEnd();}
 static TicketBackupJob Read(string id){string p=Path.Combine(Folder(id),"job.json");if(!File.Exists(p))throw new Fault("Yedek işi bulunamadı.",404);return Store.Json.Deserialize<TicketBackupJob>(ReadText(p));}
 static XmlElement Status(TicketBackupJob j){string file=Path.Combine(Folder(j.id),"status.xml");if(!File.Exists(file))return null;var x=new XmlDocument{XmlResolver=null};using(var stream=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))using(var r=XmlReader.Create(stream,new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=100000}))x.Load(r);return x.DocumentElement;}
 static bool Alive(TicketBackupJob j){if(j.pid==0)return (DateTime.UtcNow-DateTime.Parse(j.started,null,System.Globalization.DateTimeStyles.RoundtripKind)).TotalMinutes<2;try{using(var p=Process.GetProcessById(j.pid))return !p.HasExited&&Math.Abs((p.StartTime.ToUniversalTime()-DateTime.Parse(j.processStarted,null,System.Globalization.DateTimeStyles.RoundtripKind)).TotalSeconds)<2;}catch{return false;}}
 public static string ActiveID(){if(!File.Exists(Active))return "";return ReadText(Active).Trim();}
 public static bool IsRunning(){Reconcile();if(!File.Exists(Active))return false;string id=ReadText(Active).Trim();if(id=="")return false;return !Read(id).finished;}
 public static void RequireIdle(){if(IsRunning())throw new Fault("Bir yedek işlemi sürüyor. Tamamlandıktan sonra tekrar deneyin.",409);}
 static void Manifest(TicketBackupJob j,Api a){string app=Path.GetFullPath(Store.Root),database=Store.Physical("database");string entry=j.full?(Inside(database,app)?"ticket/"+database.Substring(app.TrimEnd('\\','/').Length+1).Replace('\\','/'):"external/database/Ticket.mdb"):"database/Ticket.mdb";var x=new XmlDocument{XmlResolver=null};var c=x.CreateElement("backup");x.AppendChild(c);c.SetAttribute("root",app);c.SetAttribute("database",database);c.SetAttribute("provider",new OleDbConnectionStringBuilder(a.Db.ConnectionString).Provider);c.SetAttribute("backup",Store.Physical("backups"));c.SetAttribute("destination",j.destination);c.SetAttribute("databaseEntry",entry);c.SetAttribute("full",j.full?"true":"false");c.AppendChild(x.CreateTextNode("Ticket — "+(j.full?"Tam proje":"Yalnız MDB")+" yedeği\r\nUTC: "+DateTime.UtcNow.ToString("o")+"\r\nMDB ZIP yolu: "+entry+"\r\nKonumlar: "+Store.Json.Serialize(Store.Paths)+"\r\nGeri yüklerken App_Data/storage.xml yollarını hedef sunucuya göre kontrol edin. SMTP/IMAP parolalarını farklı sunucuda yeniden tanımlayın.\r\n"));foreach(string key in new[]{"files","photos"}){var e=x.CreateElement("extra");e.SetAttribute("name",key);e.SetAttribute("path",Store.Physical(key));c.AppendChild(e);}using(var w=XmlWriter.Create(Path.Combine(Folder(j.id),"job.xml"),new XmlWriterSettings{Encoding=new UTF8Encoding(false)}))x.Save(w);}
 static bool Inside(string p,string root){p=Path.GetFullPath(p).TrimEnd('\\','/');root=Path.GetFullPath(root).TrimEnd('\\','/');return p.Equals(root,StringComparison.OrdinalIgnoreCase)||p.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase);}
 public static TicketBackupJob StartAutomatic(Api a,string occurrence,bool retry){return Start(a,true,"auto",true,occurrence,retry);}
 public static object Begin(Api a,bool full,string mode="manual") {a.Admin();try{var j=Start(a,full,mode,true);return new{jobId=j.id,message="Yedekleme başlatıldı.",name=j.name};}catch(Exception e){if(mode!="test"&&(!(e is Fault)||((Fault)e).Status!=409))BackupNotices.Notify(a.Db,false,"Yedekleme başlatılamadı: "+e.Message);throw;}}
 public static string Blocking(Api a,bool full,bool automatic){var j=Start(a,full,automatic?"auto":"manual",false);Drain(j);j=Read(j.id);if(j.error!="")throw new Fault(j.error);return j.name;}
 static TicketBackupJob Start(Api a,bool full,string mode,bool background,string occurrence="",bool retry=false){
  lock(Store.Gate){RequireIdle();string exe=Path.Combine(Store.Root,"maintenance","TicketBackupWorker.exe");if(!File.Exists(exe))throw new Fault("maintenance/TicketBackupWorker.exe eksik. V11.70 maintenance klasörünü de kopyalayın.");
   FileStream dispatch;try{dispatch=new FileStream(Path.Combine(Area,"dispatch.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}catch(IOException){throw new Fault("Başka bir yedek başlatılıyor. Biraz sonra tekrar deneyin.",409);}
   using(dispatch){RequireIdle();string claim=Path.Combine(Area,"schedule-claim.txt");if(mode=="auto"&&File.Exists(claim)){var previous=ReadText(claim).Split('|');DateTime lastAttempt;if(previous.Length==3&&previous[0]==occurrence&&(!retry||DateTime.TryParse(previous[2],null,System.Globalization.DateTimeStyles.RoundtripKind,out lastAttempt)&&(DateTime.UtcNow-lastAttempt.ToUniversalTime()).TotalMinutes<1))return null;}string backup=Store.Physical("backups");if(Inside(Store.Root,backup)||Inside(Store.Physical("database"),backup))throw new Fault("Yedek klasörü uygulama kökü veya aktif MDB ile çakışamaz.");Directory.CreateDirectory(backup);
    var j=new TicketBackupJob{id=Guid.NewGuid().ToString("N"),full=full,mode=mode,user=a.Me.ID,started=DateTime.UtcNow.ToString("o")};
    j.name="Ticket-"+(mode=="auto"?"Auto-":"")+(full?"Tam":"MDB")+"-"+TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow,TimeZoneInfo.FindSystemTimeZoneById("Turkey Standard Time")).ToString("yyyyMMdd-HHmmss")+"-"+j.id.Substring(0,6)+".zip";j.destination=Path.Combine(backup,j.name);
    Directory.CreateDirectory(Folder(j.id));Manifest(j,a);Save(j);Atomic(Active,j.id);if(mode=="auto")Atomic(claim,occurrence+"|"+j.id+"|"+DateTime.UtcNow.ToString("o"));
    Process p=null;try{
     a.Db.Close();OleDbConnection.ReleaseObjectPool();
     p=new Process{StartInfo=new ProcessStartInfo(exe,"\""+Path.Combine(Folder(j.id),"job.xml")+"\""){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=Path.GetDirectoryName(exe),RedirectStandardOutput=true,RedirectStandardError=true}};
     p.ErrorDataReceived+=(s,e)=>{};p.Start();p.BeginErrorReadLine();j.pid=p.Id;j.processStarted=p.StartTime.ToUniversalTime().ToString("o");Save(j);
     bool ready=false;string line;while((line=p.StandardOutput.ReadLine())!=null){if(line.StartsWith("snapshot-ready|",StringComparison.Ordinal)){ready=true;break;}if(line.StartsWith("error|",StringComparison.Ordinal))throw new Fault(Message(line));}
     if(!ready)throw new Fault("Yedek yardımcı işlemi başlayamadı. maintenance dosyalarının çalıştırma iznini ve .NET Framework kurulumunu kontrol edin.");
     a.Db.Open();Processes[j.id]=p;
     if(background)ThreadPool.QueueUserWorkItem(_=>Drain(j));return j;
    }catch(Exception e){if(p!=null){try{if(!p.HasExited)p.Kill();p.WaitForExit(5000);}catch{}p.Dispose();}j.error=e.Message;j.finished=true;Save(j);Atomic(Active,"");throw;}
    finally{if(a.Db.State==System.Data.ConnectionState.Closed)a.Db.Open();}
   }
  }
 }
 static readonly System.Collections.Concurrent.ConcurrentDictionary<string,Process> Processes=new System.Collections.Concurrent.ConcurrentDictionary<string,Process>();
 static string Message(string line){try{return Encoding.UTF8.GetString(Convert.FromBase64String(line.Split('|')[4]));}catch{return "Yedek yardımcı işlemi hata verdi.";}}
 static void Drain(TicketBackupJob j){Process p;try{if(Processes.TryGetValue(j.id,out p)){string line;while((line=p.StandardOutput.ReadLine())!=null){}p.WaitForExit();if(p.ExitCode!=0){var s=Status(j);j.error=s==null?"Yedek yardımcı işlemi tamamlanamadı.":s.GetAttribute("message");}}}catch(Exception e){j.error=e.Message;}finally{if(Processes.TryRemove(j.id,out p))p.Dispose();try{lock(Store.Gate){Finish(j);}}catch{/* The local scheduled worker and progress endpoint reconcile durable status next time. */}}}
 public static void Reconcile(){lock(Store.Gate){if(!File.Exists(Active))return;string id=ReadText(Active).Trim();if(id=="")return;var j=Read(id);if(j.finished){Atomic(Active,"");return;}var s=Status(j);if(s!=null&&(s.GetAttribute("phase")=="complete"||s.GetAttribute("phase")=="error")){if(s.GetAttribute("phase")=="error")j.error=s.GetAttribute("message");Finish(j);}else if(!Alive(j)){j.error="Yedek yardımcı işlemi kesildi. Başarı doğrulanamadı; yeniden deneyin.";Finish(j);}}}
 static void Finish(TicketBackupJob j){
  FileStream guard;try{guard=new FileStream(Path.Combine(Area,"finish.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}catch(IOException){return;}
  using(guard){using(var db=Store.Open()){
   bool accounted=Store.Get(db,"backup.job.done."+j.id,"")=="1";
   if(!accounted){var s=Status(j);if(j.error==""&&(s==null||s.GetAttribute("phase")!="complete"||!File.Exists(j.destination)))j.error="ZIP tamamlanması doğrulanamadı. Yedek listesini kontrol edip tekrar deneyin.";
    using(var tx=db.BeginTransaction()){BackupSchedule.Finished(db,tx,j);Store.Exec(db,tx,"INSERT INTO MaintenanceJobs (UserID,ActionName,DetailText,CreatedAt) VALUES (?,?,?,?)",j.user,j.error==""?"backup":"backup-error",j.error==""?j.name:j.error,DateTime.UtcNow);Store.Set(db,tx,"backup.job.done."+j.id,"1");tx.Commit();}
    try{BackupNotices.Notify(db,j.error=="",j.error==""?"Yedek oluşturuldu: "+j.name:"Yedekleme başarısız: "+j.error);}catch(Exception e){Store.Set(db,null,"backup.notice.lastError",e.Message);}
    if(j.mode=="auto"&&j.error=="")BackupSchedule.RetainAfterSuccess(db,j.user);
   }
  }j.finished=true;Save(j);if(File.Exists(Active)&&ReadText(Active).Trim()==j.id)Atomic(Active,"");}
  Mailer.Kick();
 }
 public static object Progress(Api a){a.Admin();Reconcile();var j=Read(a.S("id"));var s=Status(j);long b=0,t=0,f=0;if(s!=null){long.TryParse(s.GetAttribute("bytes"),out b);long.TryParse(s.GetAttribute("total"),out t);long.TryParse(s.GetAttribute("files"),out f);}return new{id=j.id,name=j.name,done=j.finished,success=j.finished&&j.error=="",error=j.error,phase=j.finished?(j.error==""?"success":"error"):s==null?"start":s.GetAttribute("phase"),message=j.finished?(j.error==""?"Yedek oluşturuldu: "+j.name:j.error):s==null?"Yedek hazırlanıyor…":s.GetAttribute("message"),bytes=b,total=t,files=f};}
}
}
