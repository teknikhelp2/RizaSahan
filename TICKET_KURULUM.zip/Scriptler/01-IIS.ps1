﻿Import-Module ServerManager
$os=Get-CimInstance Win32_OperatingSystem
if($os.ProductType -eq 1){throw 'Bu paket Windows Server 2022/2025 icindir.'}
$names=@('Web-Server','Web-Default-Doc','Web-Static-Content','Web-Http-Errors','Web-Http-Logging','Web-Filtering','Web-Url-Auth','Web-Stat-Compression','Web-Mgmt-Console','Web-Scripting-Tools','Web-Net-Ext45','Web-Asp-Net45','Web-ISAPI-Ext','Web-ISAPI-Filter','NET-Framework-45-ASPNET')
$missing=@();foreach($name in $names){$feature=Get-WindowsFeature $name;if(-not$feature){throw "Windows bileseni bulunamadi: $name"};if($feature.Installed){Mesaj "KURULU - atlandi: $name" OK}else{$missing+=$name}}
if($missing.Count){$r=Install-WindowsFeature -Name $missing -IncludeManagementTools;if(-not$r.Success){throw 'IIS bilesenleri kurulamadi. Windows kurulum kaynagini ve Sunucu Yoneticisini kontrol edin.'};if($r.RestartNeeded -eq 'Yes'){Mesaj 'Sunucuyu yeniden baslatip ayni dosyayi tekrar calistirin.' Uyari;exit 3010}}
$release=(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release).Release
if($release -lt 528040){throw '.NET Framework 4.8 veya ustunu kurup yeniden deneyin.'}
Import-Module WebAdministration
if(-not(Get-Website -Name $Site)){throw 'IIS > Sites altinda Default Web Site yok. 80 portunda Default Web Site olusturun; sonra yeniden deneyin.'}
$bindings=@(Get-WebBinding -Name $Site -Protocol http | Where-Object {$_.bindingInformation -match ':80:$'})
if(-not$bindings.Count){throw 'Default Web Site baglamalarina http / port 80 / bos ana bilgisayar adi ekleyin. Yeni ayri TICKET sitesi olusturmayin.'}
Mesaj 'IIS ve .NET hazir. Default Web Site / 80 kullanilacak.' OK
