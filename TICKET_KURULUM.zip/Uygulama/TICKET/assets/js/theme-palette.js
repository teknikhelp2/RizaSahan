/* Shared color-picker implementation; each project persists through its own save path. */
(()=>{'use strict';
 const root=document.documentElement,hex=v=>/^#[0-9a-f]{6}$/i.test(v||'');
 const svg='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1.5-3.3 1.5 1.5 0 0 1 1.2-2.5H18A3 3 0 0 0 21 12a9 9 0 0 0-9-9Z"/><circle cx="7.5" cy="10" r="1"/><circle cx="10" cy="6.5" r="1"/><circle cx="15" cy="7" r="1"/><circle cx="17.5" cy="11" r="1"/></svg>';
 window.PortalPalette={add(host,change,value){if(!host)return;const label=document.createElement('label');label.className='portal-color-picker';label.title='Paletten özel renk seç';label.innerHTML=svg;const input=document.createElement('input');input.type='color';input.value=hex(value)?value:'#2875ce';input.setAttribute('aria-label','Paletten özel renk seç');input.addEventListener('input',()=>change(input.value));input.addEventListener('change',e=>e.stopPropagation());label.append(input);host.append(label);}};
 const paletteCSS=document.createElement('link');paletteCSS.rel='stylesheet';paletteCSS.href=new URL('theme-palette.css?v=20261106',document.currentScript?.src||location.href).href;document.head.append(paletteCSS);
 const vars=['--accent','--accent-strong','--soft','--accent-ink','--portal-option-accent','--portal-pattern-color','--login-accent','--login-button-ink','--portal-tone-h','--portal-tone-s','--palette-ink','--palette-on'];
 function apply(){const a=root.dataset.loginAccent||root.dataset.accent||root.dataset.portalScrollAccent,custom=a==='white'||hex(a);if(!custom){if(root.hasAttribute('data-palette-custom')){vars.forEach(v=>root.style.removeProperty(v));delete root.dataset.paletteCustom;}return;}
  root.dataset.paletteCustom='1';const c=a==='white'?'#ffffff':a,dark=(root.dataset.loginTheme||root.dataset.mode||root.dataset.theme||root.dataset.portalScrollTheme)==='dark';const n=[1,3,5].map(k=>parseInt(c.slice(k,k+2),16)),l=n.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;});const lum=l[0]*.2126+l[1]*.7152+l[2]*.0722,on=lum>.179?'#193452':'#ffffff';
  // Keep text readable even when the chosen accent is white or very dark.
  const ink=dark?(lum<.18?'#d6e5fa':c):(lum>.45?'#47566b':c),soft=dark?'color-mix(in srgb,'+c+' 17%,#19283b)':'color-mix(in srgb,'+c+' 12%,#f1f4f8)';
  const values={'--accent':c,'--accent-strong':c,'--soft':soft,'--accent-ink':ink,'--portal-option-accent':ink,'--portal-pattern-color':'color-mix(in srgb,'+ink+' 13%,transparent)','--login-accent':c,'--login-button-ink':on,'--palette-ink':ink,'--palette-on':on,'--portal-tone-h':'210','--portal-tone-s':'12%'};
  Object.entries(values).forEach(([k,v])=>root.style.setProperty(k,v));
 }
 new MutationObserver(apply).observe(root,{attributes:true,attributeFilter:['data-mode','data-theme','data-accent','data-login-theme','data-login-accent','data-portal-scroll-accent','data-portal-scroll-theme']});apply();
})();
