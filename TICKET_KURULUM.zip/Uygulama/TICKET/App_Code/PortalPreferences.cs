using System;using System.Linq;using System.Collections.Generic;using System.Data.OleDb;using System.Text.RegularExpressions;using System.Web;
namespace CelikelTicket {
public sealed class OwnAppearance {public string family="default",mode="light",accent="yellow",pattern="rings";public int size=0;}
public static class PortalPreferences {
 public static string NormalizePattern(string value){if(value=="orbits")return "rings";if(value=="none")return "plain";return value;}
 static string Key(int id){return "user.appearance."+id;}
 public static OwnAppearance Read(OleDbConnection db,int id){string raw=Store.Get(db,Key(id),"");var p=raw==""?new OwnAppearance():Store.Json.Deserialize<OwnAppearance>(raw);p.pattern=NormalizePattern(p.pattern);if(p.size!=0)p.size=Math.Max(9,Math.Min(14,p.size));return p;}
 public static object Save(Api a){if(a.Me==null)throw new Fault("Oturum gerekli.",401);var p=new OwnAppearance{family=a.S("family","default"),size=a.N("size"),mode=a.S("mode","light"),accent=a.S("accent","yellow"),pattern=NormalizePattern(a.S("pattern","rings"))};if(!new[]{"default","Segoe UI","Arial","Calibri","Tahoma","Verdana"}.Contains(p.family)||p.size!=0&&(p.size<9||p.size>14)||!new[]{"light","dark"}.Contains(p.mode)||(!new[]{"yellow","blue","red","green","purple","orange","white"}.Contains(p.accent)&&!System.Text.RegularExpressions.Regex.IsMatch(p.accent??"","^#[0-9a-fA-F]{6}$"))||!new[]{"rings","waves","dots","grid","plain"}.Contains(p.pattern))throw new Fault("Görünüm seçimini kontrol edin.");Store.Set(a.Db,null,Key(a.Me.ID),Store.Json.Serialize(p));return p;}
}
public static class AttachmentPolicy {
 public static readonly string[] Basic={"jpg","jpeg","png","pdf","bmp","tif","xls","xlsx","doc","docx"};
 const string Denied="asp,aspx,ashx,asmx,asax,config,dll,exe,msi,com,scr,bat,cmd,ps1,vbs,vbe,js,jse,html,htm,svg,lnk,jar,hta";
 public static string Normalize(string raw){var values=(raw??"").ToLowerInvariant().Split(new[]{',',';',' ','\r','\n','\t'},StringSplitOptions.RemoveEmptyEntries).Select(x=>x.Trim().TrimStart('*').TrimStart('.')).Distinct().ToArray();if(values.Length>40||values.Any(x=>!Regex.IsMatch(x,"^[a-z0-9]{1,10}$")||Denied.Split(',').Contains(x)))throw new Fault("Uzantıları .csv, .zip gibi virgülle ayırın. Çalıştırılabilir veya web kodu uzantıları kullanılamaz.");return string.Join(",",values);}
 public static string[] Allowed(OleDbConnection db){string basic=Store.Get(db,"fileExtensions",string.Join(",",Basic)),custom=Store.Get(db,"fileCustomExtensions","gif,ppt,pptx,txt");return Normalize(basic+","+custom).Split(new[]{','},StringSplitOptions.RemoveEmptyEntries);}
 public static void Check(OleDbConnection db,string filename){string ext=System.IO.Path.GetExtension(filename).TrimStart('.').ToLowerInvariant();if(!Allowed(db).Contains(ext))throw new Fault("Bu dosya uzantısına izin verilmiyor: ."+ext);}
}
public sealed class BackupNoticePlan {public bool enabled=false,success=false,failed=true,admins=false;public string emails="";}
public static class BackupNotices {
 const string Key="backup.notification.plan";
 public static BackupNoticePlan Read(OleDbConnection db){string raw=Store.Get(db,Key,"");return raw==""?new BackupNoticePlan():Store.Json.Deserialize<BackupNoticePlan>(raw);}
 public static object Data(Api a){a.Admin();return Read(a.Db);}
 public static object Save(Api a){a.Admin();var p=new BackupNoticePlan{enabled=a.B("enabled"),success=a.B("success"),failed=a.B("failed"),admins=a.B("admins"),emails=a.S("emails").Trim()};var recipients=p.emails.Split(',').Select(x=>x.Trim()).Where(x=>x!="").Distinct(StringComparer.OrdinalIgnoreCase).ToArray();if(recipients.Length>20||recipients.Any(x=>!Api.Email(x)))throw new Fault("En fazla 20 geçerli alıcıyı virgülle ayırın.");if(p.enabled&&(!p.success&&!p.failed||!p.admins&&recipients.Length==0))throw new Fault("Bildirim olayı ve alıcı seçin.");p.emails=string.Join(", ",recipients);Store.Set(a.Db,null,Key,Store.Json.Serialize(p));return "Yedekleme bildirim kuralları kaydedildi.";}
 public static void Notify(OleDbConnection db,bool success,string message){var p=Read(db);if(!p.enabled||success&&!p.success||!success&&!p.failed)return;var emails=new HashSet<string>(p.emails.Split(',').Select(x=>x.Trim()).Where(Api.Email),StringComparer.OrdinalIgnoreCase);if(p.admins)foreach(var row in Store.Rows(db,null,"SELECT Email FROM Users WHERE IsActive=True AND RoleName='admin'")){string email=Store.Text(row["Email"]);if(Api.Email(email))emails.Add(email);}string title=success?"Yedekleme tamamlandı":"Yedekleme başarısız",color=success?"#38986b":"#d14760";string body=MailDesign.Mark("general")+"<h2 style='color:"+color+"'>"+title+"</h2><p style='font-size:14px;line-height:1.6'>"+HttpUtility.HtmlEncode(message)+"</p><p style='font-size:12px;color:#72839a'>"+DateTime.UtcNow.AddHours(3).ToString("dd.MM.yyyy HH:mm")+"</p>";foreach(string email in emails)Mailer.Queue(db,null,email,"Ticket · "+title,body);}
}
}
