﻿param([string]$Yedek='')
$folder=Join-Path $Kit 'YEDEKLER';New-Item -ItemType Directory -Path $folder -Force | Out-Null
function Yedek-Klasoru([string]$Path,[int]$Depth=0){
 if(Test-Path -LiteralPath (Join-Path $Path 'App_Code\Store.cs') -PathType Leaf){return $true}
 if($Depth -ge 3){return $false}
 foreach($child in Get-ChildItem -LiteralPath $Path -Directory -Force){
  if($child.Name -match '^(?i:Backups?|Gecici|\$RECYCLE.BIN|System Volume Information)$' -or ($child.Attributes -band [IO.FileAttributes]::ReparsePoint)){continue}
  if(Yedek-Klasoru $child.FullName ($Depth+1)){return $true}
 };return $false
}
Mesaj "Yedek aranan klasor: $folder"
$entries=@(Get-ChildItem -LiteralPath $folder -Force)
$choices=@($entries | Where-Object {
 if($_.Attributes -band [IO.FileAttributes]::ReparsePoint){return $false}
 if($_.PSIsContainer){return (Yedek-Klasoru $_.FullName)}
 return $_.Extension -in '.zip','.mdb'
})
if(-not$Yedek){
 if($choices.Count -eq 1){$Yedek=$choices[0].FullName}
 elseif($choices.Count -gt 1){
  Mesaj "Birden fazla yedek bulundu ($($choices.Count)). Silmenize gerek yok; kullanilacak yedegi secin." Uyari
  for($i=0;$i -lt $choices.Count;$i++){Mesaj ("{0}. {1}" -f ($i+1),$choices[$i].Name)}
  $answer=Read-Host 'Yedegin numarasini veya ZIP dosyasinin tam yolunu yazin'
  $number=0;if([int]::TryParse($answer,[ref]$number) -and $number -ge 1 -and $number -le $choices.Count){$Yedek=$choices[$number-1].FullName}else{$Yedek=$answer}
 }else{
  Mesaj 'Bu klasorde kullanilabilir ZIP, MDB veya Ticket proje klasoru bulunamadi.' Uyari
  if($entries.Count){Mesaj ('Klasorde gorulenler: '+(($entries | Select-Object -First 15 -ExpandProperty Name) -join ', '))}else{Mesaj 'Klasor bos gorunuyor.' Uyari}
  $Yedek=Read-Host 'Eski yedek ZIP dosyasinin tam yolunu yapistirin (ornegin C:\TICKET_KURULUM\YEDEKLER\Ticket.zip)'
 }
}
$Yedek=$Yedek.Trim().Trim('"').Trim("'")
if(-not$Yedek){throw 'Yedek secilmedi. Eski canli ZIP dosyasinin tam yolunu girin.'}
$Yedek=Yerel $Yedek
if(-not(Test-Path -LiteralPath $Yedek)){throw "Secilen yedek bulunamadi: $Yedek. Dosya uzantisini ve tam yolunu kontrol edin."}
$item=Get-Item -LiteralPath $Yedek
if(-not$item.PSIsContainer -and $item.Extension -notin '.zip','.mdb'){throw "Desteklenmeyen dosya: $($item.Name). ZIP veya MDB secin; RAR/7Z dosyasinin yalniz adini degistirmeyin."}
Mesaj ("Secilen yedek: {0}" -f $item.FullName) OK
$work=Join-Path $Kit ('Gecici\yedek-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $work -Force | Out-Null

$mdbOnly=$false
if($item.Extension -eq '.zip'){
 Add-Type -AssemblyName System.IO.Compression.FileSystem;$z=[IO.Compression.ZipFile]::OpenRead($item.FullName)
 try{$seen=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase);foreach($e in $z.Entries){$name=$e.FullName.Replace('/','\');$dest=[IO.Path]::GetFullPath((Join-Path $work $name));Altinda $dest $work;if(-not$seen.Add($dest)){throw 'ZIP icinde cift dosya adi var.'};if($e.Name){New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null;[IO.Compression.ZipFileExtensions]::ExtractToFile($e,$dest)}else{New-Item -ItemType Directory -Path $dest -Force | Out-Null}}}finally{$z.Dispose()}
 $root=$work
 $manifest=Join-Path $work 'Yedek-Bilgisi.txt'
 if(Test-Path -LiteralPath $manifest){
  $verified=0;foreach($line in Get-Content -LiteralPath $manifest){
   if($line -match '^([A-Fa-f0-9]{64})\s*\|\s*([0-9]+)\s*\|\s*(.+)$'){
    $hash=$Matches[1];$size=[long]$Matches[2];$file=Join-Path $work $Matches[3].Trim();Altinda $file $work
    if(-not(Test-Path -LiteralPath $file -PathType Leaf) -or (Get-Item -LiteralPath $file).Length -ne $size -or (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $hash){throw 'Yedek dogrulamasi basarisiz. Dosya eksik veya degismis; farkli basarili yedek secin.'};$verified++
   }
  };if(-not$verified){throw 'Yedek manifestosu okunamadi.'};Mesaj "Yedek butunlugu dogrulandi: $verified dosya." OK
 }
}elseif($item.PSIsContainer){$root=$item.FullName;$null=Yerel $root}else{
 $mdbOnly=$true;$root=Join-Path $work 'TICKET';Agac-Kopyala "$Kit\Uygulama\TICKET" $root;Copy-Item -LiteralPath $item.FullName -Destination "$root\App_Data\Ticket.mdb" -Force
}
if(-not$mdbOnly){
 $candidates=@();if(Test-Path -LiteralPath "$root\App_Code\Store.cs"){$candidates+=Get-Item -LiteralPath $root}
 $candidates+=@(Get-ChildItem -LiteralPath $root -Directory -Recurse | Where-Object {(Test-Path -LiteralPath (Join-Path $_.FullName 'App_Code\Store.cs')) -and $_.FullName -notmatch '(?i)\\Backups?\\'})
 if($candidates.Count -eq 0){$dbs=@(Get-ChildItem -LiteralPath $root -Filter *.mdb -Recurse -File);if($dbs.Count -eq 1){$mdbOnly=$true;$root=Join-Path $work 'mdb-kurtarma';Agac-Kopyala "$Kit\Uygulama\TICKET" $root;Copy-Item -LiteralPath $dbs[0].FullName -Destination "$root\App_Data\Ticket.mdb" -Force}else{throw 'Yedekte tek bir tam Ticket uygulamasi veya tek MDB bulunamadi.'}}
 elseif($candidates.Count -ne 1){throw 'Yedekte birden fazla Ticket uygulamasi var. Tek proje yedegi kullanin.'}else{
  $source=$candidates[0].FullName;$root=Join-Path $work 'hazir';Agac-Kopyala $source $root
  # External paths must be supplied inside the backup; never follow A-server absolute paths on B.
  $storage=Join-Path $source 'App_Data\storage.xml'
  if(Test-Path -LiteralPath $storage){$xml=Xml-Oku $storage;foreach($key in 'database','files','photos'){
   $node=$xml.SelectSingleNode('/storage/'+$key);if(-not$node){continue};$value=$node.InnerText
   $relative=-not[IO.Path]::IsPathRooted($value)
   $path=if($relative){[IO.Path]::GetFullPath((Join-Path $source $value))}else{''}
   if($relative -and $path.StartsWith($source.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $path)){
    $dest=if($key -eq 'database'){Join-Path $root 'App_Data\Ticket.mdb'}elseif($key -eq 'files'){Join-Path $root 'App_Data\Files'}else{Join-Path $root 'App_Data\Photos'}
    if($key -eq 'database'){Copy-Item -LiteralPath $path -Destination $dest -Force}elseif($path -ne (Join-Path $source ('App_Data\'+(Split-Path $dest -Leaf)))){Agac-Kopyala $path $dest}
   }else{
    $external=Join-Path $work ('external\'+$key);if($key -eq 'database'){$external=Join-Path $external 'Ticket.mdb'}
    if(-not(Test-Path -LiteralPath $external)){throw "Yedekte $key dosyalari yok. storage.xml eski sunucuda harici konum gosteriyor. Tam yedege external\$key ekleyin; yalniz MDB icin tek MDB kullanin."}
    $dest=if($key -eq 'database'){Join-Path $root 'App_Data\Ticket.mdb'}elseif($key -eq 'files'){Join-Path $root 'App_Data\Files'}else{Join-Path $root 'App_Data\Photos'}
    if($key -eq 'database'){Copy-Item -LiteralPath $external -Destination $dest -Force}else{Agac-Kopyala $external $dest}
   }
  }}
 }
}
if($mdbOnly){Mesaj 'YALNIZ MDB: kayitlar gelir; ekler, logolar ve fotograflar MDB icinde degildir. Tam klasor yedegi tercih edin.' Uyari}
Calistir "$Kit\Scriptler\DbTool.exe" @('validate',"$root\App_Data\Ticket.mdb")
Mesaj "Kullanilacak yedek: $($item.Name) / $($item.LastWriteTime)"
& "$PSScriptRoot\02-Kur.ps1" -Source $root -Restore
