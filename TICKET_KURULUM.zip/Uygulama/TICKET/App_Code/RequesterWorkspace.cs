using System;using System.Linq;
namespace CelikelTicket {
public static class RequesterWorkspace {
 public static object Summary(Api a){if(a.Me.Tech)throw new Fault("Bu özet kullanıcı çalışma alanı içindir.",403);var states=Store.Rows(a.Db,null,"SELECT StateName,COUNT(*) AS TotalCount FROM Tickets WHERE IsDeleted=False AND (RequesterID=? OR CreatorID=?) GROUP BY StateName",a.Me.ID,a.Me.ID);int total=states.Sum(x=>Store.Int(x["TotalCount"])),closed=states.Where(x=>Store.Text(x["StateName"])=="resolved").Sum(x=>Store.Int(x["TotalCount"]));DateTime from=DateTime.UtcNow.AddMonths(-1);int recent=Store.Int(Store.Scalar(a.Db,null,"SELECT COUNT(*) FROM Tickets WHERE IsDeleted=False AND (RequesterID=? OR CreatorID=?) AND CreatedAt>=?",a.Me.ID,a.Me.ID,from));return new{open=total-closed,closed=closed,total=total,lastMonth=recent,since=from};}
}
}
