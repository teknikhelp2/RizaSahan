using System;using System.Linq;using System.Data;using System.Data.OleDb;using System.Collections.Generic;using System.Web;
namespace CelikelTicket {
// Identity details for existing records only. This table is never used for authentication or directory editing.
public static class PersonHistory {
 public static bool Ready;
 static readonly string[] Fields={"UserName","FirstName","LastName","Email","Department","JobTitle","Phone","ManagerID","LocationID","RoleName","PhotoFile","CreatedAt","VersionNo","DepartmentID"};
 public static void Ensure(OleDbConnection db){
  if(!Store.TableExists(db,"PersonIdentities"))Store.Exec(db,null,"CREATE TABLE PersonIdentities (ID LONG PRIMARY KEY,UserName TEXT(100),FirstName TEXT(100),LastName TEXT(100),Email TEXT(200),Department TEXT(150),JobTitle TEXT(150),Phone TEXT(60),ManagerID LONG,LocationID LONG,RoleName TEXT(20),PhotoFile TEXT(100),CreatedAt DATETIME,VersionNo LONG,DepartmentID LONG)");
  using(var rows=db.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,new object[]{null,null,"TicketPeopleHistory",null})){if(rows.Rows.Count==0){string fields=string.Join(",",Fields.Select(f=>"IIF(u.ID IS NULL,h.["+f+"],u.["+f+"]) AS ["+f+"]"));Store.Exec(db,null,"CREATE VIEW TicketPeopleHistory AS SELECT h.ID,"+fields+",IIF(u.ID IS NULL,False,u.IsActive) AS IsActive FROM PersonIdentities h LEFT JOIN Users u ON h.ID=u.ID");}}
  Track(db,null);Ready=true;
 }
 public static void Track(OleDbConnection db,OleDbTransaction tx){Store.Exec(db,tx,"INSERT INTO PersonIdentities (ID) SELECT u.ID FROM Users u LEFT JOIN PersonIdentities h ON u.ID=h.ID WHERE h.ID IS NULL");}
 public static int Next(OleDbConnection db,OleDbTransaction tx){return Math.Max(Store.Int(Store.Scalar(db,tx,"SELECT MAX(ID) FROM PersonIdentities")),Store.Int(Store.Scalar(db,tx,"SELECT MAX(ID) FROM Users")))+1;}
 public static object Delete(Api a,int id){
  using(var tx=a.Db.BeginTransaction()){
   Track(a.Db,tx);
   Store.Exec(a.Db,tx,"UPDATE PersonIdentities h INNER JOIN Users u ON h.ID=u.ID SET "+string.Join(",",Fields.Select(f=>"h.["+f+"]=u.["+f+"]"))+" WHERE h.ID=?",id);
   Store.Exec(a.Db,tx,"DELETE FROM LoginSessions WHERE UserID=?",id);Store.Exec(a.Db,tx,"DELETE FROM ResetTokens WHERE UserID=?",id);Store.Exec(a.Db,tx,"DELETE FROM UserGroups WHERE UserID=?",id);Store.Exec(a.Db,tx,"DELETE FROM TicketNotifications WHERE UserID=?",id);
   string raw=Store.Text(Store.Scalar(a.Db,tx,"SELECT SettingValue FROM Settings WHERE SettingKey='security.policy.v1'"));if(raw!=""){var p=Store.Json.Deserialize<SecurityPolicy.Policy>(raw);if(p!=null&&(p.excludedUsers??new int[0]).Contains(id)){p.excludedUsers=p.excludedUsers.Where(x=>x!=id).ToArray();Store.Set(a.Db,tx,"security.policy.v1",Store.Json.Serialize(p));}}
   if(Store.Exec(a.Db,tx,"DELETE FROM Users WHERE ID=?",id)!=1)throw new Fault("Kullanıcı bulunamadı.",404);
   Store.Audit(a.Db,tx,0,a.Me.ID,"user.deleted","Kullanıcı #"+id+" kalıcı silindi. Önceki kayıtlar ve kişi bilgileri korundu.");tx.Commit();
  }
  HttpRuntime.Cache.Remove("Ticket.Security.Policy.v1");return "Kullanıcı kalıcı silindi. Geçmiş kayıtlarındaki kişi bilgileri korundu.";
 }
}
}
