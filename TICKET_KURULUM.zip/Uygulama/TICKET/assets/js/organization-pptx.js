'use strict';
window.TicketOrganizationPowerPoint=(()=>{
 let library;
 function load(){if(window.PptxGenJS)return Promise.resolve();if(!library)library=new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='assets/vendor/pptxgen.bundle.js?v=1';s.onload=resolve;s.onerror=()=>{library=null;reject(Error('PowerPoint bileşeni yüklenemedi. Sayfayı yenileyin.'));};document.head.append(s);});return library;}
 const hex=(value,fallback='DCE4EF')=>{if(/^#[0-9a-f]{6}$/i.test(value))return value.slice(1);const a=value.match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)/);return a?a.slice(1,4).map(n=>Number(n).toString(16).padStart(2,'0')).join(''):fallback;};
 const visible=e=>getComputedStyle(e).display!=='none'&&e.getBoundingClientRect().height>0;
 async function image(img,square=false){try{if(!img.complete)await Promise.race([img.decode().catch(()=>{}),new Promise(resolve=>setTimeout(resolve,8000))]);if(!img.naturalWidth)return null;const c=document.createElement('canvas');c.width=square?128:img.naturalWidth;c.height=square?128:img.naturalHeight;const k=square?Math.max(c.width/img.naturalWidth,c.height/img.naturalHeight):1;c.getContext('2d').drawImage(img,(c.width-img.naturalWidth*k)/2,(c.height-img.naturalHeight*k)/2,img.naturalWidth*k,img.naturalHeight*k);return c.toDataURL('image/png');}catch{return null;}}
 function segments(path){const parts=path.match(/[MVH][^MVH]*/gi)||[];let x=0,y=0;const lines=[];for(const part of parts){const values=(part.slice(1).match(/-?\d+(?:\.\d+)?(?:e[-+]?\d+)?/gi)||[]).map(Number),command=part[0].toUpperCase();if(command==='M'){x=values[0];y=values[1];continue;}const nx=command==='H'?values[0]:x,ny=command==='V'?values[0]:y;lines.push({x1:x,y1:y,x2:nx,y2:ny});x=nx;y=ny;}return lines;}
 async function snapshot(canvas,drawLinks){
  const stage=document.createElement('div');stage.className='org-export-stage org-balanced org-tiered';const copy=canvas.cloneNode(true);copy.querySelectorAll('[id]').forEach(e=>e.removeAttribute('id'));for(const e of [copy,...copy.querySelectorAll('[style]')])e.style.zoom='1';stage.append(copy);document.body.append(stage);
  try{
   await document.fonts.ready;await Promise.all([...stage.querySelectorAll('img')].map(img=>image(img)));drawLinks(stage);
   const pages=[],sheets=[...stage.querySelectorAll('.org-department-sheet')],sources=sheets.length?sheets:[copy];
   for(const source of sources){const diagram=source.querySelector('.org-diagram');if(!diagram)continue;const origin=diagram.getBoundingClientRect(),rect=e=>{const r=e.getBoundingClientRect();return {x:r.left-origin.left,y:r.top-origin.top,w:r.width,h:r.height};};const cards=[];
    for(const element of diagram.querySelectorAll('.org-company,.org-person')){const company=element.classList.contains('org-company'),r=rect(element),texts=[];for(const el of element.querySelectorAll(company?'span:not(.company-logo-pair)':'strong,span,small,em')){if(!visible(el)||el.children.length||!el.textContent.trim())continue;const style=getComputedStyle(el);texts.push({...rect(el),text:el.textContent.trim(),size:parseFloat(style.fontSize)*.75,bold:Number(style.fontWeight)>=600,color:hex(style.color,'193452'),align:style.textAlign==='center'?'center':'left'});}const photos=[];for(const img of element.querySelectorAll('img'))if(visible(img)){const data=await image(img,!company);if(data)photos.push({...rect(img),data,avatar:!company});}cards.push({...r,company,texts,photos});
    }
    const links=[...diagram.querySelectorAll('.org-diagram-lines path')].flatMap(p=>segments(p.getAttribute('d')||''));pages.push({title:source.dataset.departmentTitle||'',width:diagram.scrollWidth,height:diagram.scrollHeight,cards,links});
   }
   return pages;
  }finally{stage.remove();}
 }
 async function exportChart(canvas,drawLinks){
  await load();const pages=await snapshot(canvas,drawLinks);if(!pages.length)throw Error('Aktarılacak organizasyon şeması bulunamadı.');const pptx=new window.PptxGenJS();pptx.defineLayout({name:'ORG_A4_YATAY',width:11.692913,height:8.267717});pptx.layout='ORG_A4_YATAY';pptx.author='Ticket';pptx.subject='Departmanlara göre organizasyon şeması';pptx.title='Organizasyon Şeması';pptx.company='Ticket';pptx.lang='tr-TR';pptx.theme={headFontFace:'Segoe UI',bodyFontFace:'Segoe UI',lang:'tr-TR'};
  const accent=hex(getComputedStyle(document.documentElement).getPropertyValue('--accent').trim(),'F4BC04');
  for(const page of pages){const slide=pptx.addSlide();slide.background={color:'FFFFFF'};slide.addShape(pptx.ShapeType.rect,{x:.3,y:.3,w:11.092913,h:7.667717,line:{color:'CBD8E8',width:.65},fill:{color:'FFFFFF'},radius:0});slide.addText('Organizasyon Şeması'+(page.title?' / '+page.title:''),{x:.5,y:.44,w:10.69,h:.3,fontFace:'Segoe UI',fontSize:13,color:'193452',margin:0,breakLine:false});
   const area={x:.5,y:.95,w:10.692913,h:6.797717},scale=Math.min(area.w/Math.max(1,page.width),area.h/Math.max(1,page.height)),ox=area.x+(area.w-page.width*scale)/2,oy=area.y+(area.h-page.height*scale)/2;
   const box=r=>({x:ox+r.x*scale,y:oy+r.y*scale,w:r.w*scale,h:r.h*scale});
   for(const l of page.links)slide.addShape(pptx.ShapeType.line,{x:ox+Math.min(l.x1,l.x2)*scale,y:oy+Math.min(l.y1,l.y2)*scale,w:Math.abs(l.x2-l.x1)*scale,h:Math.abs(l.y2-l.y1)*scale,line:{color:accent,width:.65,beginArrowType:'none',endArrowType:'none'}});
   for(const card of page.cards){slide.addShape(pptx.ShapeType.roundRect,{...box(card),rectRadius:.06,line:{color:card.company?accent:'DCE4EF',width:.65},fill:{color:card.company?'FFFFFF':'F8FAFC'},radius:.06});for(const p of card.photos)slide.addImage({data:p.data,...box(p),rounding:p.avatar});for(const t of card.texts)slide.addText(t.text,{...box(t),fontFace:'Segoe UI',fontSize:Math.max(1,t.size*scale*96),bold:t.bold,color:t.color,align:t.align,margin:0,verticalAnchor:'middle',valign:'mid',fit:'shrink',paraSpaceAfterPt:0,breakLine:false});}
   slide.addNotes('Ticket organizasyon şeması. Kişi kartları, metinler ve bağlantılar PowerPoint içinde düzenlenebilir.');
  }
  await pptx.writeFile({fileName:'Celikel-Ticket-Organizasyon-Semasi.pptx'});
 }
 return {exportChart};
})();
