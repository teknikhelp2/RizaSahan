﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$Kit=Split-Path $PSScriptRoot -Parent
$Target='C:\inetpub\wwwroot\TICKET'
$Site='Default Web Site';$Pool='TICKET'
function Mesaj([string]$Text,[string]$Tur='Bilgi'){$color=switch($Tur){'OK'{'Green'}'Hata'{'Red'}'Uyari'{'Yellow'}default{'Gray'}};Write-Host $Text -ForegroundColor $color}
function Calistir([string]$Exe,[string[]]$Arguments){
 $old=$ErrorActionPreference;try{$ErrorActionPreference='Continue';$lines=@(& $Exe @Arguments 2>&1);$code=$LASTEXITCODE}finally{$ErrorActionPreference=$old}
 foreach($line in $lines){$kind=if($code){'Hata'}elseif([string]$line -match '(?i)warning|uyari'){'Uyari'}else{'OK'};Mesaj ([string]$line) $kind};if($code){throw "Islem tamamlanamadi: $([IO.Path]::GetFileName($Exe)), kod $code"}
}
function Yerel([string]$Path){
 if($Path -notmatch '^[A-Za-z]:\\' -or $Path.Contains('..')){throw 'Tam yerel Windows yolu gerekir.'}
 $full=[IO.Path]::GetFullPath($Path).TrimEnd('\');$walk=$full
 while($walk){if((Test-Path -LiteralPath $walk) -and ((Get-Item -LiteralPath $walk -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw "Junction/sembolik baglanti kullanilamaz: $walk"};$walk=[IO.Path]::GetDirectoryName($walk)};return $full
}
function Altinda([string]$Path,[string]$Root){$p=Yerel $Path;$r=(Yerel $Root)+'\';if(-not$p.StartsWith($r,[StringComparison]::OrdinalIgnoreCase)){throw 'Dosya yolu izin verilen klasorun disinda.'}}
function Paket-Kontrol {
 foreach($f in (Get-Content "$Kit\Dosya-Manifestosu.json" -Raw | ConvertFrom-Json)){
  $path=Join-Path $Kit $f.Path;Altinda $path $Kit
  if(-not(Test-Path -LiteralPath $path -PathType Leaf)){throw "Paket eksik: $($f.Path). Tam TICKET_KURULUM.zip paketini yeniden cikarin."}
  if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $f.SHA256){throw "Paket dosyasi degismis: $($f.Path). Tam paketi yeniden cikarin."}
 }
}
function Havuzu-Durdur {
 if((Get-WebAppPoolState $Pool).Value -ne 'Stopped'){Stop-WebAppPool $Pool}
 $until=(Get-Date).AddSeconds(30);do{if((Get-WebAppPoolState $Pool).Value -eq 'Stopped'){return};Start-Sleep -Milliseconds 200}while((Get-Date) -lt $until);throw 'TICKET havuzu durmadi. Dosyalar degistirilmedi.'
}
function Sahiplik-Kontrol {
 $app=Get-WebApplication -Site $Site -Name TICKET -ErrorAction SilentlyContinue
 $marker=Join-Path $Target 'App_Data\kurulum.json'
 if($app -or (Test-Path -LiteralPath $Target)){
  if(-not(Test-Path -LiteralPath $marker)){throw "Hedefte bu pakete ait olmayan TICKET var: $Target. Mevcut klasoru once yedekleyip baska konuma tasiyin; ilgili TICKET IIS kaydini kaldirin. Default Web Site veya ITCONTROL'u silmeyin."}
  $m=Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json
  if($m.Kind -ne 'TICKET-KURULUM' -or $m.Computer -ne $env:COMPUTERNAME -or $m.Target -ne $Target -or ($app -and ($app.PhysicalPath -ne $Target -or $app.ApplicationPool -ne $Pool))){throw 'TICKET kurulum bilgisi uyusmuyor. Mevcut sisteme dokunulmadi.'}
 }elseif(Test-Path "IIS:\AppPools\$Pool"){throw 'TICKET isimli havuz zaten var ve bu pakete ait degil. Baska uygulama kullanmiyorsa IIS uygulama havuzlarindan bu eski havuzu kaldirip tekrar deneyin.'}
 if(@(Get-WebApplication | Where-Object {$_.ApplicationPool -eq $Pool -and $_.PhysicalPath -ne $Target}).Count){throw 'TICKET havuzunu baska uygulama da kullaniyor. Once ayri havuza alin.'}
 if(@(Get-Website | Where-Object {$_.applicationPool -eq $Pool}).Count){throw 'TICKET havuzu baska bir sitenin kok uygulamasinda kullaniliyor.'}
 return [bool]$app
}
function Agac-Kopyala([string]$From,[string]$To){
 New-Item -ItemType Directory -Path $To -Force | Out-Null
 foreach($f in Get-ChildItem -LiteralPath $From -Recurse -Force){
  if($f.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Kaynakta junction/sembolik baglanti var.'}
  $rel=$f.FullName.Substring($From.TrimEnd('\').Length+1)
  if($rel -match '(?i)^App_Data\\(Backups?|BackupJobs)(\\|$)' -or $f.Extension -in '.ldb','.laccdb','.log' -or $f.Name -in 'kurulum.json','security-recovery.config','OTOMASYON-DURAKLATILDI.txt'){continue}
  $dest=Join-Path $To $rel;Altinda $dest $To
  if($f.PSIsContainer){New-Item -ItemType Directory -Path $dest -Force | Out-Null}else{
   New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null
   $sourceStream=[IO.File]::Open($f.FullName,'Open','Read','None');try{$output=[IO.File]::Open($dest,'Create','Write','None');try{$sourceStream.CopyTo($output)}finally{$output.Dispose()}}finally{$sourceStream.Dispose()}
  }
 }
}
function Xml-Oku([string]$Path){$s=New-Object Xml.XmlReaderSettings;$s.DtdProcessing='Prohibit';$s.XmlResolver=$null;$r=[Xml.XmlReader]::Create($Path,$s);try{$x=New-Object Xml.XmlDocument;$x.XmlResolver=$null;$x.Load($r);return ,$x}finally{$r.Dispose()}}
function Kurtarma-Uyarla([string]$App,[bool]$Restore){
 $data=Join-Path $App 'App_Data';New-Item -ItemType Directory -Path $data -Force | Out-Null
 foreach($d in 'Files','Photos','Backups','BackupJobs'){New-Item -ItemType Directory -Path (Join-Path $data $d) -Force | Out-Null}
 [IO.File]::WriteAllText((Join-Path $data 'storage.xml'),'<storage><database>App_Data/Ticket.mdb</database><files>App_Data/Files</files><photos>App_Data/Photos</photos><backups>App_Data/Backups</backups></storage>')
 Copy-Item -LiteralPath "$Kit\Scriptler\Deployment.cs" -Destination "$App\App_Code\Deployment.cs" -Force
 $globalFile=Join-Path $App 'Global.asax';$text=[IO.File]::ReadAllText($globalFile)
 if($text -notmatch 'Deployment.Begin'){$text=$text.Replace('if(!CelikelTicket.BackupHeartbeat.Local(Context))','if(CelikelTicket.Deployment.Begin(Context))return;if(!CelikelTicket.BackupHeartbeat.Local(Context))');if($text -notmatch 'Deployment.Begin'){throw 'Global.asax bu paketle uyumlu degil.'};[IO.File]::WriteAllText($globalFile,$text,(New-Object Text.UTF8Encoding($false)))}
 foreach($pair in @(@('Mailer.cs','public static void Kick(){','public static void Kick(){if(!Deployment.AutomationAllowed)return;'),@('WorkPlanning.cs','public static void Start(){lock(Store.Gate)','public static void Start(){if(!Deployment.AutomationAllowed)return;lock(Store.Gate)'))){
  $file=Join-Path "$App\App_Code" $pair[0];$text=[IO.File]::ReadAllText($file)
  if($text -notmatch 'Deployment.AutomationAllowed'){if(-not$text.Contains($pair[1])){throw "Uyumsuz otomasyon dosyasi: $($pair[0])"};[IO.File]::WriteAllText($file,$text.Replace($pair[1],$pair[2]),(New-Object Text.UTF8Encoding($false)))}
 }
 # Preserve an explicitly supplied machineKey. Auto-generated keys cannot be recovered on another server.
 Maintenance-Korumasi-Kur $App
 $config=Join-Path $App 'web.config';$xml=Xml-Oku $config
 if(-not$xml.SelectSingleNode('/configuration/system.web/machineKey')){
  $mk=$xml.CreateElement('machineKey');$rng=[Security.Cryptography.RandomNumberGenerator]::Create()
  try{foreach($pair in @(@('validationKey',64),@('decryptionKey',32))){$bytes=New-Object byte[] $pair[1];$rng.GetBytes($bytes);$mk.SetAttribute($pair[0],([BitConverter]::ToString($bytes).Replace('-','')))}}finally{$rng.Dispose()}
  $mk.SetAttribute('validation','HMACSHA256');$mk.SetAttribute('decryption','AES');$null=$xml.SelectSingleNode('/configuration/system.web').AppendChild($mk);$xml.Save($config)
 }
 if($Restore){
  [IO.File]::WriteAllText((Join-Path $data 'security-recovery.config'),'<recovery disableHttps="true" />')
  [IO.File]::WriteAllText((Join-Path $data 'OTOMASYON-DURAKLATILDI.txt'),'Yeni sunucuda mail, uygulama adresi ve planlari kontrol edin. Sonra C:\TICKET_KURULUM\3-OTOMASYONU-AC.bat dosyasini yonetici olarak calistirin.')
 }
}

function Plan-Gorevi-Kur {
 try{
  $action=New-ScheduledTaskAction -Execute "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument '-NoProfile -NonInteractive -Command "try { Invoke-WebRequest -Uri http://localhost/TICKET/app/backup-heartbeat.ashx -Method POST -UseBasicParsing -TimeoutSec 110 | Out-Null } catch { exit 1 }"'
  $trigger=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1)
  $principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 2) -StartWhenAvailable
  Register-ScheduledTask -TaskName 'TICKET-Plan-Kontrol' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
 }catch{Mesaj "Portal kuruldu; periyodik plan gorevi kurulamadi: $($_.Exception.Message). 1-KURULUMU-BASLAT.bat tekrarinda kurulum korunur; destek icin bu uyariyi saklayin." Uyari}
}

function Maintenance-Korumasi-Kur([string]$App) {
 $config=Join-Path $App 'web.config';Altinda $config $App
 $xml=Xml-Oku $config;$configuration=$xml.SelectSingleNode('/configuration')
 if(-not$configuration){throw 'web.config configuration dugumu eksik.'}
 $parent=$configuration
 foreach($name in 'system.webServer','security','requestFiltering','hiddenSegments'){
  $node=$parent.SelectSingleNode($name)
  if(-not$node){$node=$xml.CreateElement($name);$null=$parent.AppendChild($node)}
  $parent=$node
 }
 # Keep all inherited hidden segments (App_Data, bin, etc.). Only normalize our own entry.
 foreach($node in @($parent.ChildNodes)){
  if($node.NodeType -eq [Xml.XmlNodeType]::Element -and $node.GetAttribute('segment') -ieq 'maintenance'){$null=$parent.RemoveChild($node)}
 }
 foreach($name in 'remove','add'){$node=$xml.CreateElement($name);$node.SetAttribute('segment','maintenance');$null=$parent.AppendChild($node)}
 $temporary=Join-Path $App ('web.config.maintenance-'+[guid]::NewGuid().ToString('N')+'.tmp');Altinda $temporary $App
 try{$xml.Save($temporary);[IO.File]::Replace($temporary,$config,[NullString]::Value)}finally{if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary}}
}
function Gizli-Dosya-Durumu([string]$Url){
 $request=[Net.HttpWebRequest]::Create($Url)
 $request.Method='GET';$request.Proxy=$null;$request.AllowAutoRedirect=$false
 $request.Timeout=15000;$request.ReadWriteTimeout=15000
 $request.CachePolicy=New-Object Net.Cache.RequestCachePolicy -ArgumentList ([Net.Cache.RequestCacheLevel]::NoCacheNoStore)
 $response=$null
 try{
  try{$response=$request.GetResponse()}catch{
   $errorCause=$_.Exception
   while($errorCause -and $errorCause -isnot [Net.WebException]){$errorCause=$errorCause.InnerException}
   if($errorCause -and $errorCause.Response){$response=$errorCause.Response}else{throw}
  }
  # Inspect response headers only. Never read/write the protected file body, or follow a login redirect.
  return [pscustomobject]@{Status=[int]$response.StatusCode;Location=[string]$response.Headers['Location']}
 }finally{$request.Abort();if($response){$response.Close()}}
}
function Gizli-Dosyalari-Kontrol([string]$Base='http://localhost/TICKET'){
 foreach($hidden in 'App_Data/Ticket.mdb','maintenance/TicketBackupWorker.exe'){
  $result=Gizli-Dosya-Durumu ($Base.TrimEnd('/')+'/'+$hidden)
  if($result.Status -notin 401,403,404){
   $detail=if($result.Location){'; yonlendirme: '+$result.Location}else{''}
   throw "Gizli dosya korumasi dogrulanamadi: $hidden, HTTP $($result.Status)$detail. Kurulum durduruldu; bu kontrolu atlamayin. URL Authorization ve maintenance istek filtresi denetlenmeli."
  }
  Mesaj "KORUNUYOR: $hidden (HTTP $($result.Status))" OK
 }
}
