Option Explicit
Dim fso,shell,folder,runner,temp,xml,stream,status,command,stamp
Set fso=CreateObject("Scripting.FileSystemObject"):Set shell=CreateObject("WScript.Shell")
folder=fso.GetParentFolderName(WScript.ScriptFullName):runner=fso.BuildPath(folder,"Run-Backup.vbs")
If Not fso.FileExists(runner) Then WScript.Echo "Run-Backup.vbs bulunamadi.":WScript.Quit 1
If Not fso.FileExists(fso.BuildPath(folder,"TicketBackupWorker.exe")) Then WScript.Echo "TicketBackupWorker.exe eksik. V11.70 maintenance klasorunu tamamen kopyalayin.":WScript.Quit 1
status=shell.Run(Chr(34) & fso.BuildPath(folder,"TicketBackupWorker.exe") & Chr(34) & " --selftest",0,True)
If status<>0 Then WScript.Echo "Yedek yardimcisi calismadi. .NET Framework 4.5 veya ustunu ve dosya calistirma izinlerini kontrol edin.":WScript.Quit status
stamp=Year(Now()) & "-" & Right("0" & Month(Now()),2) & "-" & Right("0" & Day(Now()),2) & "T" & Right("0" & Hour(Now()),2) & ":" & Right("0" & Minute(Now()),2) & ":00"
xml="<?xml version=""1.0"" encoding=""UTF-16""?><Task version=""1.2"" xmlns=""http://schemas.microsoft.com/windows/2004/02/mit/task""><RegistrationInfo><Description>Ticket kayitli yedekleme planini tarayicidan bagimsiz kontrol eder.</Description></RegistrationInfo><Triggers><CalendarTrigger><Repetition><Interval>PT1M</Interval><Duration>P1D</Duration><StopAtDurationEnd>false</StopAtDurationEnd></Repetition><StartBoundary>" & stamp & "</StartBoundary><Enabled>true</Enabled><ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay></CalendarTrigger></Triggers><Principals><Principal id=""Author""><UserId>S-1-5-18</UserId><RunLevel>HighestAvailable</RunLevel></Principal></Principals><Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><StartWhenAvailable>true</StartWhenAvailable><Enabled>true</Enabled><ExecutionTimeLimit>PT2H10M</ExecutionTimeLimit></Settings><Actions Context=""Author""><Exec><Command>" & EscapeXML(shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\cscript.exe") & "</Command><Arguments>//B //Nologo &quot;" & EscapeXML(runner) & "&quot;</Arguments><WorkingDirectory>" & EscapeXML(folder) & "</WorkingDirectory></Exec></Actions></Task>"
temp=fso.BuildPath(fso.GetSpecialFolder(2),fso.GetTempName()):Set stream=fso.CreateTextFile(temp,True,True):stream.Write xml:stream.Close
command="schtasks.exe /Create /TN ""Celikel Ticket Backup Plan"" /XML """ & temp & """ /F"
status=shell.Run(command,0,True):fso.DeleteFile temp,True
If status<>0 Then WScript.Echo "Kurulamadi. SUNUCUDA Kur-Gorev.cmd dosyasini Yonetici olarak calistirin.":WScript.Quit status
WScript.Echo "Celikel Ticket Backup Plan kuruldu. Her dakika portaldaki plani kontrol eder. Tarayici acik kalmak zorunda degil. Windows Gorev Zamanlayici ekranindan kontrol edebilirsiniz."
Function EscapeXML(value)
 EscapeXML=Replace(Replace(Replace(value,"&","&amp;"),"<","&lt;"),">","&gt;")
End Function
