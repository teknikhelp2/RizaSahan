﻿param([ValidateSet('Kur','Don','Ac','Kontrol')][string]$Islem='Kur')
. "$PSScriptRoot\Ortak.ps1"
try{
 if($PSVersionTable.PSEdition -ne 'Desktop' -or -not[Environment]::Is64BitProcess){throw '64 bit Windows PowerShell 5.1 kullanin.'}
 $id=[Security.Principal.WindowsIdentity]::GetCurrent();if(-not(New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'BAT dosyasina sag tiklayin > Yonetici olarak calistir.'}
 $null=Yerel $Kit;$null=Yerel $Target;Paket-Kontrol
 if($Islem -in 'Kur','Don'){& "$PSScriptRoot\01-IIS.ps1";if($Islem -eq 'Kur'){& "$PSScriptRoot\02-Kur.ps1"}else{& "$PSScriptRoot\03-Don.ps1"}}
 else{Import-Module WebAdministration;$exists=Sahiplik-Kontrol;if(-not$exists){throw 'Once 1-KURULUMU-BASLAT.bat calistirin.'}
  if($Islem -eq 'Ac'){
   Mesaj 'Mail, uygulama adresi ve otomatik gorevleri kontrol ettiniz mi? Bu islem mail alip gonderebilir ve planli ticket olusturabilir.' Uyari
   if((Read-Host 'Etkinlestirmek icin EVET yazin') -cne 'EVET'){throw 'Otomasyon acilmadi.'}
   Havuzu-Durdur;try{$file=Join-Path $Target 'App_Data\OTOMASYON-DURAKLATILDI.txt';if(Test-Path -LiteralPath $file){Remove-Item -LiteralPath $file}}finally{Start-WebAppPool $Pool};Mesaj 'Otomasyon etkin. Mail ve plan sonuclarini portalda kontrol edin.' OK
  }else{
   Calistir "$PSScriptRoot\DbTool.exe" @('validate',"$Target\App_Data\Ticket.mdb")
   $r=Invoke-WebRequest 'http://localhost/TICKET/index.aspx' -UseBasicParsing -TimeoutSec 90;if($r.StatusCode -ne 200 -or $r.Content -notmatch 'login-form'){throw 'Giris sayfasi acilmiyor.'};Mesaj 'Portal ve veritabani erisimi basarili.' OK
   if(Test-Path "$Target\App_Data\OTOMASYON-DURAKLATILDI.txt"){Mesaj 'Otomasyon duraklatilmis. Kontrollerden sonra 3-OTOMASYONU-AC.bat.' Uyari}
  }
 }
 exit 0
}catch{Mesaj ("HATA: "+$_.Exception.Message) Hata;exit 1}
