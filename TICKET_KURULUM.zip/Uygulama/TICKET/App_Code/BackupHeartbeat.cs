using System;
using System.Web;
namespace CelikelTicket {
// Local Windows scheduled task only. No password or user session is used or extended.
public sealed class BackupHeartbeat:IHttpHandler {
 public static bool Local(HttpContext c){string remote=c.Request.ServerVariables["REMOTE_ADDR"];return c.Request.FilePath.Equals(c.Request.ApplicationPath.TrimEnd('/')+"/app/backup-heartbeat.ashx",StringComparison.OrdinalIgnoreCase)&&c.Request.HttpMethod=="POST"&&(remote=="127.0.0.1"||remote=="::1"||remote=="::ffff:127.0.0.1");}
 public bool IsReusable{get{return false;}}
 public void ProcessRequest(HttpContext c){c.Response.Cache.SetCacheability(HttpCacheability.NoCache);c.Response.TrySkipIisCustomErrors=true;c.Response.ContentType="application/json; charset=utf-8";
  string remote=c.Request.ServerVariables["REMOTE_ADDR"];
  if(!Local(c)){c.Response.StatusCode=403;c.Response.Write("{\"ok\":false}");return;}
  try{if(Store.Root==null)Store.Init(c.Server.MapPath("~/"));lock(Store.Gate){using(var db=Store.Open())BackupSchedule.RunDue(db,DateTime.UtcNow);}Mailer.Kick();c.Response.Write("{\"ok\":true,\"message\":\"Plan kontrol edildi. Yedek sonucu portalda izlenebilir.\"}");}
  catch(Exception e){c.Response.StatusCode=500;try{System.IO.File.AppendAllText(System.IO.Path.Combine(c.Server.MapPath("~/App_Data"),"backup-heartbeat.log"),DateTime.UtcNow.ToString("o")+" "+e.Message+Environment.NewLine);}catch{}c.Response.Write("{\"ok\":false,\"message\":\"Plan kontrolü tamamlanamadı. Portal yedekleme durumunu kontrol edin.\"}");}
 }
}
}
